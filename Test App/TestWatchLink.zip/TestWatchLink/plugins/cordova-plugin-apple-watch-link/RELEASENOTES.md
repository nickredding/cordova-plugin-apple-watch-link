## Release Notes

#### 1.0.0 (February 23, 2021)

* Initial release.

#### 1.0.1 (February 26, 2021)

* Bug fixes.
* Add direct messaging to test app.

#### 1.0.2

* Bug fixes.
* Added complication testing to the test app.

#### 1.0.3

* Bug fixes.

#### 1.0.4

* Bug fixes
* Send session reset via user information transfer if watch app is in background

