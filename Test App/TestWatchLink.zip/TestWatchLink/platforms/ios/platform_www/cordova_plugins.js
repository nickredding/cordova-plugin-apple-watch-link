cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-apple-watch-link.watchLink",
      "file": "plugins/cordova-plugin-apple-watch-link/www/watchLink.js",
      "pluginId": "cordova-plugin-apple-watch-link",
      "clobbers": [
        "cordova.plugins.watchLink"
      ]
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-whitelist": "1.3.4",
    "cordova-plugin-apple-watch-link": "1.0.7"
  };
});