/* global cordova */
document.addEventListener('deviceready', onDeviceReady, false);

var watchLink;

function onDeviceReady() {
    watchLink = window.cordova.plugins.watchLink;
    document.getElementById('deviceready').classList.add('ready');
    watchLink.appLog('Running cordova-' + cordova.platformId + '@' + cordova.version);
    // messaging and access to status must wait until the watchLink Swift layer has completed initialization
    watchLink.ready(onWatchLinkReady);
    
    document.getElementById('useack').checked = true;
    document.getElementById('usedirect').checked = false;
    // handlers can be bound as soon as the plugin has initialized
    watchLink.availabilityChanged(
        function(status) {
        if (status === true) {
            document.getElementById('available').classList.add('is');
            document.getElementById('available').classList.remove('isnot');
        }
        else {
            document.getElementById('available').classList.add('isnot');
            document.getElementById('available').classList.remove('is');
        }
        });
    watchLink.reachabilityChanged(
        function(status) {
            if (status === true) {
                document.getElementById('reachable').classList.add('is');
                document.getElementById('reachable').classList.remove('isnot');
            }
            else {
                document.getElementById('reachable').classList.add('isnot');
                document.getElementById('reachable').classList.remove('is');
            }
        });
    watchLink.applicationStateChanged(
        function(state) {
            if (state == null) {
                return;
            }
            if (state.state === 'ACTIVE') {
                document.getElementById('state').classList.add('active');
                document.getElementById('state').classList.remove('inactive','background','isnot');
            }
            else
            if (state.state === 'INACTIVE') {
                document.getElementById('state').classList.add('inactive');
                document.getElementById('state').classList.remove('active','background','isnot');
            }
            else
            if (state.state === 'BACKGROUND') {
                document.getElementById('state').classList.add('background');
                document.getElementById('state').classList.remove('active','inactive','isnot');
            }
            if (watchLink.applicationState.complication) {
                document.getElementById('havecomplication').classList.add('is');
                document.getElementById('havecomplication').classList.remove('isnot');
            }
            else {
                document.getElementById('havecomplication').classList.add('isnot');
                document.getElementById('havecomplication').classList.remove('is');
            }
        });
    watchLink.bindMessageHandler('TEST',
    function(mtype, mbody) {
        var timestamp = mbody.TIMESTAMP;
        delete mbody.TIMESTAMP;
        toConsole('RCV msg<br>&nbsp;&nbsp;' + timestamp + '<br>&nbsp;&nbsp;' + JSON.stringify(mbody));
        watchLink.appLog('RCV msg ' + JSON.stringify(mbody));
    });
    
    watchLink.bindMessageHandler(null,
    function(mtype, mbody) {
        toConsole('RCV default msg<br>&nbsp;&nbsp;' + mtype + ':<br>&nbsp;&nbsp;' + JSON.stringify(mbody));
        watchLink.appLog('RCV default msg ' + mtype + ": " + JSON.stringify(mbody));
    });
    
    watchLink.bindDataMessageHandler(
    function(data) {
        var view = new Uint8Array(data);
        toConsole('RCV DATA<br>&nbsp;&nbsp;' + JSON.stringify(view));
        watchLink.appLog('RCV DATA: ' + JSON.stringify(view));
    });
    
    watchLink.bindContextHandler(
        function(context) {
            toConsole('RCV context<br>&nbsp;&nbsp;' + JSON.stringify(context));
            delete context.TIMESTAMP;
            delete context.SESSION;
            delete context.ACK;
            watchLink.appLog('RCV context ' + JSON.stringify(context));
        });
    
    watchLink.bindUserInfoHandler(
        function(userinfo) {
        var timestamp = userinfo.TIMESTAMP;
        watchLink.appLog('RCV user info ' + JSON.stringify(userinfo));
        delete userinfo.TIMESTAMP;
        delete userinfo.SESSION;
        delete userinfo.ACK;
        toConsole('RCV user info<br>&nbsp;&nbsp;' + timestamp + '<br>&nbsp;&nbsp;' + JSON.stringify(userinfo));
        });
    
    watchLink.requestNotificationPermission(true)
        .then(
            function() {
                toConsole('Notifications permitted');
                watchLink.appLog('Notifications permitted');
            })
        .catch(
            function(msg) {
                toConsole('Notifications denied:<br>&nbsp;&nbsp;' + msg);
                watchLink.appLog('Notifications denied: ' + msg);
            });
    
    watchLink.bindNotificationHandler(
        function(userInfo) {
            toConsole('Notification handler:<br>&nbsp;&nbsp;' + JSON.stringify(userInfo));
            watchLink.appLog('Notification handler:' + JSON.stringify(userInfo));
            if (lastNotification && lastNotification === userInfo.TIMESTAMP) {
                lastNotification = null;
            }
        });
    watchLink.bindNotificationDelegate(
        function(userInfo) {
            toConsole('Notification delegate:<br>&nbsp;&nbsp;' + JSON.stringify(userInfo));
            watchLink.appLog('Notification delegate: ' + JSON.stringify(userInfo));
            if (lastNotification && lastNotification === userInfo.TIMESTAMP) {
                lastNotification = null;
            }
        });
    watchLink.showDelegatedNotification(true);
}

var lastNotification = null;

function onWatchLinkReady() {
    // Cordova and watchLink are now initialized.
    if (watchLink.available === true) {
        document.getElementById('available').classList.add('is');
        document.getElementById('available').classList.remove('isnot');
    }
    else {
        document.getElementById('available').classList.add('isnot');
        document.getElementById('available').classList.remove('is');
    }
    if (watchLink.reachable === true) {
        document.getElementById('reachable').classList.add('is');
        document.getElementById('reachable').classList.remove('isnot');
    }
    else {
        document.getElementById('reachable').classList.add('isnot');
        document.getElementById('reachable').classList.remove('is');
    }
    //watchLink.appLogLevel(3);
    //watchLink.watchLogLevel(3);
    //watchLink.watchPrintLogLevel(3);
    clearConsole();
}



function timeStamp(space) {
    var time = new Date();

    function addZero(i, milli) {
        if (milli) { 
            if (i < 10) {
                i = '00' + i;
            }
            else
            if (i < 100) {
                i = '0' + i;
            }
        }
        else {
            if (i < 10) {
                i = '0' + i;
            }
        }
        return i;
    }
    return '[' + addZero(time.getHours()) + ':' + addZero(time.getMinutes()) + ':' + addZero(time.getSeconds()) + '.' + addZero(time.getMilliseconds(), true) + ']' + (space ? space : '');
}

function toConsole(msg) {
    var br = document.createElement('BR'),
        text = document.createElement('DIV');
    text.innerHTML = timeStamp() + ' ' + msg;
    document.getElementById('console').appendChild(br);
    document.getElementById('console').appendChild(text);
    document.getElementById("console").scrollTop = document.getElementById("console").offsetHeight;
}

function addConsole(msg) {
    var br = document.createElement('BR'),
        text = document.createElement('DIV');
    text.innerHTML = msg;
    document.getElementById('console').appendChild(br);
    document.getElementById('console').appendChild(text);
    document.getElementById("console").scrollTop = document.getElementById("console").offsetHeight;
}

function clearConsole() {
    document.getElementById('console').innerHTML = '<br/>' + timeStamp() + ' Cleared';
}

function reset() {
    watchLink.resetSession();
}

function useAck() {
    return document.getElementById('useack').checked;
}

function useDirect() {
    return document.getElementById('usedirect').checked;
}

function testmsg(msg) {
    if (msg == null) {
        watchLink.errorLog('please provide a msg');
        return;
    }
    if (typeof msg != 'object') {
        watchLink.errorLog('please provide an object msg');
        return;
    }
    if (useDirect()) {
        watchLink.wcSessionCommand('sendMessage', msg);
        toConsole('Direct msg<br>&nbsp;&nbsp;' + JSON.stringify(msg));
        watchLink.appLog('Direct msg ' + JSON.stringify(msg));
        return;
    }
    if (useAck()) {
        watchLink.sendMessage('TEST', msg)
            .then(function(timestamp) {
                toConsole('ACK msg ' + timestamp);
                watchLink.appLog('ACK msg ' + timestamp);
            })
            .catch(function(err) {
                toConsole('ERR msg:<br>&nbsp;&nbsp;' + err);
                watchLink.errorLog('ERR msg: ' + err);
            });
    }
    else {
        watchLink.sendMessage('TEST', msg, null,
            function(err) {
                toConsole('ERR msg:<br>&nbsp;&nbsp;' + err);
                watchLink.errorLog('ERR msg: ' + err);
            });
    }
    toConsole('Msg<br>&nbsp;&nbsp;' + JSON.stringify(msg));
    watchLink.appLog('Msg ' + JSON.stringify(msg));
}

function datamsg(msg) {
    if (msg == null) {
        watchLink.errorLog('please provide a msg');
        return;
    }
    if (!Array.isArray(msg)) {
        watchLink.errorLog('msg parameter must be array');
        return;
    }
    var i;
    var buffer = new ArrayBuffer(msg.length);
    var view = new Uint8Array(buffer);
    for (i = 0; i < msg.length; i++) {
        if (typeof msg[i] !== 'number') {
            watchLink.errorLog('msg[' + i + '] is not a number:', msg[i]);
            return;
        }
        if (msg[i] < 0 || msg[i] > 255) {
            watchLink.errorLog('msg[' + i + '] is out of range', msg[i]);
            return;
        }
        view[i] = msg[i];
    }
    if (useDirect()) {
        watchLink.wcSessionCommand('sendDataMessage', buffer);
        toConsole('Direct datamsg<br>&nbsp;&nbsp;' + JSON.stringify(msg));
        watchLink.appLog('Direct data msg ' + JSON.stringify(msg));
        return;
    }
    if (useAck()) {
        watchLink.sendDataMessage(buffer)
            .then(function() {
                toConsole('ACK datamsg');
                watchLink.appLog('ACK datamsg');
            })
            .catch(function(err) {
                toConsole('ERR datamsg:<br>&nbsp;&nbsp;' + err);
                watchLink.errorLog('ERR datamsg: ' + err);
            });
    }
    else {
        watchLink.sendDataMessage(buffer, null,
            function(err) {
                toConsole('ERR datamsg:<br>&nbsp;&nbsp;' + err);
                watchLink.errorLog('ERR datamsg: ' + err);
            });
    }
    toConsole('Datamsg<br>&nbsp;&nbsp;' + JSON.stringify(msg));
    watchLink.appLog('Datamsg ' + JSON.stringify(msg));
    
}

function testcontext(context) {
    if (context == null) {
        watchLink.errorLog('please provide a context');
        return;
    }
    if (typeof context !== 'object') {
        watchLink.errorLog('please provide a context object', context);
        return;
    }
    if (useDirect()) {
        watchLink.wcSessionCommand('updateContext', context);
        toConsole('Direct context<br>&nbsp;&nbsp;' + JSON.stringify(context));
        watchLink.appLog('Direct context ' + JSON.stringify(context));
        return;
    }
    if (useAck()) {
        watchLink.sendContext(context)
            .then(function(timestamp) {
                toConsole('ACK context ' + timestamp);
                watchLink.appLog('ACK context ' + timestamp);
            })
            .catch(function(err) {
                toConsole('ERR context:<br>&nbsp;&nbsp;' + err);
                watchLink.errorLog('ERR context: ' + err);
            });
    }
    else {
        watchLink.sendContext(context, null,
            function(err) {
                toConsole('ERR context:<br>&nbsp;&nbsp;' + err);
                watchLink.errorLog('ERR context: ' + err);
            });
    }
    toConsole('Context<br>&nbsp;&nbsp;' + JSON.stringify(context));
    watchLink.appLog('Context timestamp=' + JSON.stringify(context));
}

function testuserinfo(userinfo) {
    if (userinfo == null) {
        watchLink.errorLog('please provide userinfo');
        return;
    }
    if (typeof userinfo !== 'object') {
        watchLink.errorLog('please provide a userinfo object', userinfo);
        return;
    }
    if (useDirect()) {
        watchLink.wcSessionCommand('updateUserInfo', userinfo);
        toConsole('Direct userinfo<br>&nbsp;&nbsp;' + JSON.stringify(userinfo));
        watchLink.appLog('Direct userinfo ' + JSON.stringify(userinfo));
        return;
    }
    if (useAck()) {
        watchLink.sendUserInfo(userinfo)
            .then(function(timestamp) {
                toConsole('ACK userinfo ' + timestamp);
                watchLink.appLog('ACK userinfo ' + timestamp);
            })
            .catch(function(err) {
                toConsole('ERR userinfo:<br>&nbsp;&nbsp;' + err);
                watchLink.errorLog('ERR userinfo: ' + err);
            });
        toConsole('testuserinfo timestamp=' + userinfo.TIMESTAMP);
        watchLink.appLog('testuserinfo timestamp=' + userinfo.TIMESTAMP);
    }
    else {
        watchLink.sendUserInfo(userinfo, null,
            function(err) {
                toConsole('ERR userinfo:<br>&nbsp;&nbsp;' + err);
                watchLink.errorLog('ERR userinfo: ' + err);
            });
    }
    toConsole('Userinfo<br>&nbsp;&nbsp;' + JSON.stringify(userinfo));
    watchLink.appLog('Userinfo ' + JSON.stringify(userinfo));
}

function testcomplication(userinfo) {
    if (userinfo == null) {
        watchLink.errorLog('please provide userinfo');
        return;
    }
    if (typeof userinfo !== 'object') {
        watchLink.errorLog('please provide a userinfo object', userinfo);
        return;
    }
    watchLink.sendComplicationInfo(userinfo);
    toConsole('Complication<br>&nbsp;&nbsp;' + JSON.stringify(userinfo));
    watchLink.appLog('Complication ' + JSON.stringify(userinfo));
}

function notify(delay, title, subtitle, body, userInfo) {
    delay = (delay == null ? 10 : delay);
    title = title || 'Test alert';
    subtitle = subtitle || '';
    body = body || '';
    userInfo = userInfo || {};
    watchLink.scheduleNotification(delay, { title: title, subtitle: subtitle, body: body, userInfo: userInfo })
        .then(
          function(timestamp) {
            lastNotification = timestamp;
            toConsole('Notification sent: ' + timestamp);
            watchLink.appLog('Notification sent: ' + timestamp);
            pendingNotifications();
        })
        .catch(
           function(msg) {
                watchLink.appLog('Notifications denied: ' + msg);
        });
}

function cancelNotification(timestamp) {
    timestamp = timestamp || lastNotification;
    if (timestamp) {
        watchLink.cancelNotification(timestamp);
        toConsole('Notification cancelled');
        watchLink.appLog('Notification cancelled');
        lastNotification = null;
    }
    else {
        toConsole('No pending notification');
        watchLink.appLog('No pending notification');
    }
}

function cancelAllNotifications() {
    watchLink.cancelAllNotifications();
    toConsole('All notifications cancelled');
    watchLink.appLog('All notifications cancelled');
    lastNotification = null;
}

function pendingNotifications() {
    watchLink.retrieveNotifications()
      .then(
        function(list) {
            toConsole('Notifications pending: ' + list.length);
            list.forEach(
                function(el) {
                    addConsole('<br>&nbsp;&nbsp;' + JSON.stringify(el));
                });
            watchLink.appLog('Notifications pending: ' + JSON.stringify(list));
        });
}

document.getElementById('testmsg').addEventListener('click',
function() {
    var obj = { a: Math.floor(Math.random() * 255), b: Math.floor(Math.random() * 255) };
    testmsg(obj);
});

document.getElementById('testdatamsg').addEventListener('click',
function() {
    var obj = [ Math.floor(Math.random() * 255),Math.floor(Math.random() * 255) ];
    datamsg(obj);
});

document.getElementById('userinfo').addEventListener('click',
function() {
    var obj = { x: Math.floor(Math.random() * 255), y: Math.floor(Math.random() * 255) };
    testuserinfo(obj);
});

document.getElementById('context').addEventListener('click',
function() {
    var obj = { z: Math.floor(Math.random() * 255), w: Math.floor(Math.random() * 255) };
    testcontext(obj);
});

document.getElementById('complication').addEventListener('click',
function() {
    var obj = { progress: Math.random() };
    testcomplication(obj);
});

document.getElementById('notification').addEventListener('click',
function() {
    var n = Math.floor(Math.random() * 255);
    notify(10, 'Notify ' + n, 'Subtitle ' + n, 'Body of notification ' + n, { id: n });
});

document.getElementById('cancelnotification').addEventListener('click',
function() {
    cancelNotification();
});

document.getElementById('cancelallnotifications').addEventListener('click',
function() {
    cancelAllNotifications();
});

document.getElementById('listnotifications').addEventListener('click',
function() {
    pendingNotifications();
});

document.getElementById('resetsession').addEventListener('click',
function() {
    reset();
});

document.getElementById('clearconsole').addEventListener('click', clearConsole);
