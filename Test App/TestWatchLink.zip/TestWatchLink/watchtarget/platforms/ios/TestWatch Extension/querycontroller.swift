import WatchKit
import WatchConnectivity
import Foundation

var queryInterface: queryInterfaceController?

class queryInterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        queryInterface = self
        clearConsole()
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }
    
    var useAcknowledgement = true
    var useDirect = false
    
    @IBAction func show() {
        consoleText = ""
        toConsole("Info: " + String(describing:lastInfo) + "\r\n" + "Context: " + String(describing:lastContext))
    }
    
    
    @IBOutlet weak var console: WKInterfaceLabel!
    
    var consoleText = ""
    
    func clearConsole() {
        consoleText = ""
        console.setText(consoleText)
    }
    
    func toConsole(_ msg: String) {
        consoleText += Date().timeOfDay() + "\r\n" + msg
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12.0, weight: UIFont.Weight.regular)]))
    }
}

