import WatchKit
import WatchConnectivity
import Foundation

var userinfoInterface: userinfoInterfaceController?

class userinfoInterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        userinfoInterface = self
        clearConsole()
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }
    
    private func ack(_ msg: String) {
        printAppLog("ACK userinfo \(msg)")
        toConsole("ACK userinfo \(msg)")
    }
    
    private func err(_ msg: String) {
        printAppLog("ERR userinfo \(msg)")
        toConsole("ERR userinfo \(msg)")
    }
    
    @IBAction func send() {
        let userinfo = ["X": Int.random(in: 1..<256), "Y": Int.random(in: 1..<256)] as [String : Any]
        if (useDirect) {
            let session = WCSession.default
            session.transferUserInfo(userinfo)
            printAppLog("Direct userinfo sent")
            toConsole("Direct userinfo sent")
            return
        }
        let timestamp = updateUserInfoToPhone(userinfo, ack: useAcknowledgement, ackHandler: ack, errHandler: err)
        clearConsole()
        printAppLog("Userinfo timestamp=\(timestamp)")
        toConsole("Userinfo \(timestamp)")
    }
    
    @IBAction func toggle(_ value: Bool) {
        useAcknowledgement = value
    }
    
    @IBAction func direct(_ value: Bool) {
        useDirect = value
    }
    
    var useAcknowledgement = true
    var useDirect = false
    
    @IBOutlet weak var console: WKInterfaceLabel!
    
    var consoleText = ""
    
    func clearConsole() {
        consoleText = ""
        console.setText(consoleText)
    }
    
    func toConsole(_ msg: String) {
        consoleText += "\r\n" + Date().timeOfDay() + "\r\n" + msg
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12.0, weight: UIFont.Weight.regular)]))
    }
    
}


