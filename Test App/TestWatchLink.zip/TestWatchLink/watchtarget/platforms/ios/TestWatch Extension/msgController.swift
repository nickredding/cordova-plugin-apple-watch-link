
import WatchKit
import WatchConnectivity
import Foundation

var msgInterface: msgInterfaceController?

class msgInterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        msgInterface = self
        clearConsole()
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }
    
    private func ack(_ msg: String) {
        printAppLog("ACK msg \(msg)")
        toConsole("ACK msg \(msg)")
    }
    
    private func err(_ msg: String) {
        printAppLog("ERR msg \(msg)")
        toConsole("ERR msg \(msg)")
    }
    
    @IBAction func send() {
        let msgBody = ["A": Int.random(in: 1..<256), "B": Int.random(in: 1..<256)]
        if (useDirect) {
            let session = WCSession.default
            session.sendMessage(msgBody, replyHandler: nil,
                                    errorHandler:
                                        { (response: Error) in
                                            watchErrorLog("Direct msg error " + String(describing: response))})
            printAppLog("Direct msg sent")
            toConsole("Direct msg sent")
            return
        }
        let timestamp = messageToPhone(msgType: "TEST", msgBody: msgBody, ack: useAcknowledgement, ackHandler: ack, errHandler: err, allowReserved: true)
        clearConsole()
        printAppLog("  Msg timestamp=\(timestamp)")
        toConsole("Msg \(timestamp)")
    }
    
    @IBAction func toggle(_ value: Bool) {
        useAcknowledgement = value
    }
    
    @IBAction func direct(_ value: Bool) {
        useDirect = value
    }
    
    var useAcknowledgement = true
    var useDirect = false
    
    var consoleText = ""
    
    @IBOutlet weak var console: WKInterfaceLabel!
    
    func clearConsole() {
        consoleText = ""
        console.setText(consoleText)
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 10.0, weight: UIFont.Weight.regular)]))
    }
    
    func toConsole(_ msg: String) {
        consoleText += "\r\n" + Date().timeOfDay() + "\r\n" + msg
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12.0, weight: UIFont.Weight.regular)]))
    }
}
