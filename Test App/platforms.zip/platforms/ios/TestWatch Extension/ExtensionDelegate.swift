

import WatchKit
import WatchConnectivity

class ExtensionDelegate: WatchLinkExtensionDelegate {

	private func ack(id: String) {
		toConsole("ACK " + id)
		printAppLog("ACK " + id)
	}

	private func err(error: String) {
		toConsole("ERR " + error)
		printAppLog("ERR " + error)
	}

	func msgHandler(_ msgType: String, _ msgBody: Any) -> Bool {
        var msg = msgBody as! [String: Any]
        let timestamp = msg["TIMESTAMP"] as! Int64
        printAppLog("Received " + msgType + ": " + String(describing:msgBody))
        msg.removeValue(forKey: "TIMESTAMP")
        toConsole("RCV msg\n  " + String(timestamp) + "\n  " + String(describing: msg))
        return true
	}
    
    func defaultMsgHandler(_ msgType: String, _ msgBody: Any) {
        let msg = msgBody as! [String: Any]
        printAppLog("Received default " + msgType + ": " + String(describing:msgBody))
        toConsole("RCV msg\n  " + msgType + ":\n  " + String(describing: msg))
    }
    
    func dataHandler(_ msgData: Data) {
        let array = msgData.map { UInt8($0) }
        toConsole("RCV DATA msg\n  " + String(describing:array))
        watchAppLog("Received DATA " + String(describing:array))
        printAppLog("Received DATA " + String(describing:array))
        _ = dataMessageToPhone(dataMsg: msgData, ack: true)
    }

	func contextHandler(_ id: Int64, _ context: [String: Any]) {
        guard let timestamp = context["TIMESTAMP"] as? Int64
        else {
            printAppLog("Received direct context " + String(describing:context))
            toConsole("RCV direct context\n" + String(describing:context) + "\n  ")
            return
        }
        printAppLog("Received " + String(describing:context))
        var theContext = context
        theContext.removeValue(forKey: "TIMESTAMP")
        theContext.removeValue(forKey: "SESSION")
        theContext.removeValue(forKey: "ACK")
        toConsole("RCV context\n  " + String(timestamp) + "\n  " + String(describing:theContext))
	}

	func userInfoHandler(_ id: Int64, _ userInfo: [String: Any]) {
        guard let timestamp = userInfo["TIMESTAMP"] as? Int64
        else {
            printAppLog("Received direct userinfo " + String(describing:userInfo))
            toConsole("RCV direct userinfo\n" + String(describing:userInfo) + "\n  ")
            return
        }
        printAppLog("Received userinfo " + String(describing:userInfo))
        var theInfo = userInfo
        theInfo.removeValue(forKey: "TIMESTAMP")
        theInfo.removeValue(forKey: "SESSION")
        theInfo.removeValue(forKey: "ACK")
        toConsole("RCV userinfo\n" + String(timestamp) + "\n  " + String(describing:theInfo) + "\n  ")
	}
    
    func availabilityChangedHandler(_ state: Bool) {
        if (state) {
            printLog("Availability: true")
            toConsole("Session Available")
        }
        else {
            printLog("Availability: false")
            toConsole("Session NOT Available")
        }
    }
    
    func reachabilityChangedHandler(_ state: Bool) {
        if (state) {
            printLog("Reachability: true")
            toConsole("Session Reachable")
        }
        else {
            printLog("Reachability: false")
            toConsole("Session NOT Reachable")
        }
    }
    
    func reset() {
        let session = WCSession.default
        clearMainConsole("RESET")
        if (session.isCompanionAppInstalled) {
            printLog("Availability: true")
            toConsole("Session Available")
        }
        else {
            printLog("Availability: false")
            toConsole("Session NOT Available")
        }
        if (session.isReachable) {
            printLog("Reachability: true")
            toConsole("Session Reachable")
        }
        else {
            printLog("Reachability: false")
            toConsole("Session NOT Reachable")
        }
    }

    override func applicationDidFinishLaunching() {
        // Perform any final initialization of your application.
        super.applicationDidFinishLaunching()
        printAppLog("AppExtensionDelegate.applicationDidFinishLaunching")
		bindMessageHandler(msgType: "TEST", handler: msgHandler)
        bindDefaultMessageHandler(handler: defaultMsgHandler)
        bindDataMessageHandler(handler: dataHandler)
        watchContextHandler = contextHandler
		watchUserInfoHandler = userInfoHandler
        availabilityChanged = reachabilityChangedHandler
        reachabilityChanged = availabilityChangedHandler
        watchReset(reset)
    }

    override func applicationDidBecomeActive() {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        super.applicationDidBecomeActive()
    }

    override func applicationWillResignActive() {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, etc.
        super.applicationWillResignActive()
    }

    override func handle(_ backgroundTasks: Set<WKRefreshBackgroundTask>) {
        // Sent when the system needs to launch the application in the background to process tasks. Tasks arrive in a set, so loop through and process each one.
        for task in backgroundTasks {
            // Use a switch statement to check the task type
            switch task {
            case let backgroundTask as WKApplicationRefreshBackgroundTask:
                // Be sure to complete the background task once you’re done.
                backgroundTask.setTaskCompletedWithSnapshot(false)
            case let snapshotTask as WKSnapshotRefreshBackgroundTask:
                // Snapshot tasks have a unique completion call, make sure to set your expiration date
                snapshotTask.setTaskCompleted(restoredDefaultState: true, estimatedSnapshotExpiration: Date.distantFuture, userInfo: nil)
            case let connectivityTask as WKWatchConnectivityRefreshBackgroundTask:
                // Be sure to complete the connectivity task once you’re done.
                connectivityTask.setTaskCompletedWithSnapshot(false)
            case let urlSessionTask as WKURLSessionRefreshBackgroundTask:
                // Be sure to complete the URL session task once you’re done.
                urlSessionTask.setTaskCompletedWithSnapshot(false)
            case let relevantShortcutTask as WKRelevantShortcutRefreshBackgroundTask:
                // Be sure to complete the relevant-shortcut task once you're done.
                relevantShortcutTask.setTaskCompletedWithSnapshot(false)
            case let intentDidRunTask as WKIntentDidRunRefreshBackgroundTask:
                // Be sure to complete the intent-did-run task once you're done.
                intentDidRunTask.setTaskCompletedWithSnapshot(false)
            default:
                // make sure to complete unhandled task types
                task.setTaskCompletedWithSnapshot(false)
            }
        }
    }

}
