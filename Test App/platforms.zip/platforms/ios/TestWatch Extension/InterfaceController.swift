

import WatchKit
import Foundation

var interface: InterfaceController?

class InterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        interface = self
        self.clearMainConsole("Cleared")
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }
    
    @IBOutlet weak var console: WKInterfaceLabel!
    @IBAction func clearConsole() {
        consoleText = Date().timeOfDay() + "\r\nCleared"
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12.0, weight: UIFont.Weight.regular)]))
    }
    
    func clearMainConsole(_ note: String = "Cleared") {
        consoleText = Date().timeOfDay() + "\r\n" + note
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12.0, weight: UIFont.Weight.regular)]))
    }
    var consoleText = ""
    
    func toConsole(_ msg: String) {
        consoleText += "\r\n" + Date().timeOfDay() + "\r\n" + msg
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12.0, weight: UIFont.Weight.regular)]))
    }
}

func toConsole(_ msg: String) {
    if (interface != nil) {
        interface!.toConsole(msg)
    }
}

func clearMainConsole(_ note: String = "Cleared") {
    if (interface != nil) {
        interface!.clearMainConsole(note)
    }
}
