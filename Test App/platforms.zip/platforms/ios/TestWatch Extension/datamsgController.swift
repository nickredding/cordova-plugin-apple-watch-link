import WatchKit
import WatchConnectivity
import Foundation

var datamsgInterface: datamsgInterfaceController?

class datamsgInterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        datamsgInterface = self
        clearConsole()
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }
    
    private func ack(_ msg: String) {
        printAppLog("ACK datamsg \(msg)")
        toConsole("ACK datamsg \(msg)")
    }
    
    private func err(_ msg: String) {
        printAppLog("ERR datamsg \(msg)")
        toConsole("ERR datamsg \(msg)")
    }
    
    @IBAction func send() {
        var msgBytes: [UInt8] = [UInt8(Int.random(in: 1..<256)), UInt8(Int.random(in: 1..<256))]
        let msgData = NSData(bytes: &msgBytes, length: msgBytes.count) as Data
        if (useDirect) {
            let session = WCSession.default
            session.sendMessageData(msgData, replyHandler: nil,
                                        errorHandler:
                                            { (response: Error) in
                                                watchErrorLog("Direct data msg error " + String(describing: response))})
            printAppLog("Direct data msg sent")
            toConsole("Direct data msg sent")
            return
        }
        let timestamp = dataMessageToPhone(dataMsg: msgData, ack: useAcknowledgement, ackHandler: ack, errHandler: err)
        clearConsole()
        printAppLog("Datamsg timestamp=\(timestamp)")
        toConsole("Datamsg \(timestamp)")
    }
    
    @IBAction func toggle(_ value: Bool) {
        useAcknowledgement = value
    }
    
    @IBAction func direct(_ value: Bool) {
        useDirect = value
    }
    
    var useAcknowledgement = true
    var useDirect = false
    
    @IBOutlet weak var console: WKInterfaceLabel!
    
    var consoleText = ""
    
    func clearConsole() {
        consoleText = ""
        console.setText(consoleText)
    }
    
    func toConsole(_ msg: String) {
        consoleText += "\r\n" + Date().timeOfDay() + "\r\n" + msg
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12.0, weight: UIFont.Weight.regular)]))
    }
}
