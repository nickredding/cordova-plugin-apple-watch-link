import WatchKit
import WatchConnectivity
import Foundation

var contextInterface: contextInterfaceController?

class contextInterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        contextInterface = self
        clearConsole()
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }
    
    private func ack(_ msg: String) {
        printAppLog("ACK context \(msg)")
        toConsole("ACK context \(msg)")
    }
    
    private func err(_ msg: String) {
        printAppLog("ERR context \(msg)")
        toConsole("ERR context \(msg)")
    }
    
    @IBAction func send() {
        let context = ["Z": Int.random(in: 1..<256), "W": Int.random(in: 1..<256)]
        if (useDirect) {
            let session = WCSession.default
            do {
                try session.updateApplicationContext(context)
            }
            catch {
                watchErrorLog("Direct context update error \(error)")
                toConsole("Error \(error)")
                return
            }
            printAppLog("Direct context sent")
            toConsole("Direct context sent")
            return
        }
        let timestamp = updateContextToPhone(context, ack: useAcknowledgement, ackHandler: ack, errHandler: err)
        clearConsole()
        printAppLog("Context timestamp=\(timestamp)")
        toConsole("Context \(timestamp)")
    }
    
    @IBAction func toggle(_ value: Bool) {
        useAcknowledgement = value
    }
    
    @IBAction func direct(_ value: Bool) {
        useDirect = value
    }
    
    var useAcknowledgement = true
    var useDirect = false
    
    @IBOutlet weak var console: WKInterfaceLabel!
    
    var consoleText = ""
    
    func clearConsole() {
        consoleText = ""
        console.setText(consoleText)
    }
    
    func toConsole(_ msg: String) {
        consoleText += "\r\n" + Date().timeOfDay() + "\r\n" + msg
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12.0, weight: UIFont.Weight.regular)]))
    }
}

