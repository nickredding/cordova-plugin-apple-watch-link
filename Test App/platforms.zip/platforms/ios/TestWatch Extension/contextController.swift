import WatchKit
import Foundation

var contextInterface: contextInterfaceController?

class contextInterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        contextInterface = self
        clearConsole()
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }
    
    private func ack(_ msg: String) {
        printAppLog("ACK context \(msg)")
        toConsole("ACK context \(msg)")
    }
    
    private func err(_ msg: String) {
        printAppLog("ERR context \(msg)")
        toConsole("ERR context \(msg)")
    }
    
    @IBAction func send() {
        let context = ["Z": Int.random(in: 1..<256), "W": Int.random(in: 1..<256)]
        let timestamp = updateContextToPhone(context, ack: useAcknowledgement, ackHandler: ack, errHandler: err)
        clearConsole()
        printAppLog("context timestamp=\(timestamp)")
        toConsole("context \(timestamp)")
    }
    
    @IBAction func toggle(_ value: Bool) {
        useAcknowledgement = value
    }
    
    var useAcknowledgement = true
    
    @IBOutlet weak var console: WKInterfaceLabel!
    
    var consoleText = ""
    
    func clearConsole() {
        consoleText = ""
        console.setText(consoleText)
    }
    
    func toConsole(_ msg: String) {
        consoleText += "\r\n" + Date().timeOfDay() + "\r\n" + msg
        console.setAttributedText(NSAttributedString(string: consoleText, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12.0, weight: UIFont.Weight.regular)]))
    }
}

