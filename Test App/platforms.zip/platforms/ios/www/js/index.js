/* global cordova */
document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    document.getElementById('deviceready').classList.add('ready');
    window.cordova.plugins.watchLink.appLog('Running cordova-' + cordova.platformId + '@' + cordova.version);
    // messaging and access to status must wait until the watchLink Swift layer has completed initialization
    window.cordova.plugins.watchLink.ready(onWatchLinkReady);
    
    document.getElementById('useack').checked = true;
    // handlers can be bound as soon as the plugin has initialized
    window.cordova.plugins.watchLink.availabilityChanged(
        function(status) {
        if (status === true) {
            document.getElementById('available').classList.add('is');
            document.getElementById('available').classList.remove('isnot');
        }
        else {
            document.getElementById('available').classList.add('isnot');
            document.getElementById('available').classList.remove('is');
        }
        });
    window.cordova.plugins.watchLink.reachabilityChanged(
        function(status) {
            if (status === true) {
                document.getElementById('reachable').classList.add('is');
                document.getElementById('reachable').classList.remove('isnot');
            }
            else {
                document.getElementById('reachable').classList.add('isnot');
                document.getElementById('reachable').classList.remove('is');
            }
        });
    window.cordova.plugins.watchLink.applicationStateChanged(
        function(state) {
            if (state == null) {
                return;
            }
            if (state.state === 'ACTIVE') {
                document.getElementById('state').classList.add('active');
                document.getElementById('state').classList.remove('inactive','background','isnot');
            }
            else
            if (state.state === 'INACTIVE') {
                document.getElementById('state').classList.add('inactive');
                document.getElementById('state').classList.remove('active','background','isnot');
            }
            else
            if (state.state === 'BACKGROUND') {
                document.getElementById('state').classList.add('background');
                document.getElementById('state').classList.remove('active','inactive','isnot');
            }
        });
    window.cordova.plugins.watchLink.bindMessageHandler('TEST',
    function(mtype, mbody) {
        var timestamp = mbody.TIMESTAMP;
        delete mbody.TIMESTAMP;
        toConsole('RCV msg<br>&nbsp;&nbsp;' + timestamp + '<br>&nbsp;&nbsp;' + JSON.stringify(mbody));
        window.cordova.plugins.watchLink.appLog('RCV msg ' + JSON.stringify(mbody));
    });
    
    window.cordova.plugins.watchLink.bindDataMessageHandler(
    function(data) {
        var view = new Uint8Array(data);
        toConsole('RCV DATA<br>&nbsp;&nbsp;' + JSON.stringify(view));
        window.cordova.plugins.watchLink.appLog('RCV DATA: ' + JSON.stringify(view));
    });
    
    window.cordova.plugins.watchLink.bindContextHandler(
        function(context) {
            toConsole('RCV context<br>&nbsp;&nbsp;' + JSON.stringify(context));
            delete context.TIMESTAMP;
            delete context.SESSION;
            delete context.ACK;
            window.cordova.plugins.watchLink.appLog('RCV context ' + JSON.stringify(context));
        });
    
    window.cordova.plugins.watchLink.bindUserInfoHandler(
        function(userinfo) {
        var timestamp = userinfo.TIMESTAMP;
        window.cordova.plugins.watchLink.appLog('RCV user info ' + JSON.stringify(userinfo));
        delete userinfo.TIMESTAMP;
        delete userinfo.SESSION;
        delete userinfo.ACK;
        toConsole('RCV user info<br>&nbsp;&nbsp;' + timestamp + '<br>&nbsp;&nbsp;' + JSON.stringify(userinfo));
        });
    
    window.cordova.plugins.watchLink.requestNotificationPermission(true)
        .then(
            function() {
                toConsole('Notifications permitted');
                window.cordova.plugins.watchLink.appLog('Notifications permitted');
            })
        .catch(
            function(msg) {
                toConsole('Notifications denied:<br>&nbsp;&nbsp;' + msg);
                window.cordova.plugins.watchLink.appLog('Notifications denied: ' + msg);
            });
    
    window.cordova.plugins.watchLink.bindNotificationHandler(
        function(userInfo) {
            toConsole('Notification handler:<br>&nbsp;&nbsp;' + JSON.stringify(userInfo));
            window.cordova.plugins.watchLink.appLog('Notification handler:' + JSON.stringify(userInfo));
            if (lastNotification && lastNotification === userInfo.TIMESTAMP) {
                lastNotification = null;
            }
        });
    window.cordova.plugins.watchLink.bindNotificationDelegate(
        function(userInfo) {
            toConsole('Notification delegate:<br>&nbsp;&nbsp;' + JSON.stringify(userInfo));
            window.cordova.plugins.watchLink.appLog('Notification delegate: ' + JSON.stringify(userInfo));
            if (lastNotification && lastNotification === userInfo.TIMESTAMP) {
                lastNotification = null;
            }
        });
    window.cordova.plugins.watchLink.showDelegatedNotification(true);
}

var lastNotification = null;

function onWatchLinkReady() {
    // Cordova and watchLink are now initialized.
    if (window.cordova.plugins.watchLink.available === true) {
        document.getElementById('available').classList.add('is');
        document.getElementById('available').classList.remove('isnot');
    }
    else {
        document.getElementById('available').classList.add('isnot');
        document.getElementById('available').classList.remove('is');
    }
    if (window.cordova.plugins.watchLink.reachable === true) {
        document.getElementById('reachable').classList.add('is');
        document.getElementById('reachable').classList.remove('isnot');
    }
    else {
        document.getElementById('reachable').classList.add('isnot');
        document.getElementById('reachable').classList.remove('is');
    }
    //window.cordova.plugins.watchLink.appLogLevel(3);
    //window.cordova.plugins.watchLink.watchLogLevel(3);
    //window.cordova.plugins.watchLink.watchPrintLogLevel(3);
    clearConsole();
}



function timeStamp(space) {
    var time = new Date();

    function addZero(i, milli) {
        if (milli) { 
            if (i < 10) {
                i = '00' + i;
            }
            else
            if (i < 100) {
                i = '0' + i;
            }
        }
        else {
            if (i < 10) {
                i = '0' + i;
            }
        }
        return i;
    }
    return '[' + addZero(time.getHours()) + ':' + addZero(time.getMinutes()) + ':' + addZero(time.getSeconds()) + '.' + addZero(time.getMilliseconds(), true) + ']' + (space ? space : '');
}

function toConsole(msg) {
    var br = document.createElement('BR'),
        text = document.createElement('DIV');
    text.innerHTML = timeStamp() + ' ' + msg;
    document.getElementById('console').appendChild(br);
    document.getElementById('console').appendChild(text);
    document.getElementById("console").scrollTop = document.getElementById("console").offsetHeight;
}

function addConsole(msg) {
    var br = document.createElement('BR'),
        text = document.createElement('DIV');
    text.innerHTML = msg;
    document.getElementById('console').appendChild(br);
    document.getElementById('console').appendChild(text);
    document.getElementById("console").scrollTop = document.getElementById("console").offsetHeight;
}

function clearConsole() {
    document.getElementById('console').innerHTML = '<br/>' + timeStamp() + ' Cleared';
}

function reset() {
    window.cordova.plugins.watchLink.resetSession();
}

function useAck() {
    return document.getElementById('useack').checked;
}

function testmsg(msg) {
    if (msg == null) {
        window.cordova.plugins.watchLink.errorLog('please provide a msg');
        return;
    }
    if (typeof msg != 'object') {
        window.cordova.plugins.watchLink.errorLog('please provide an object msg');
        return;
    }
    if (useAck()) {
        window.cordova.plugins.watchLink.sendMessage('TEST', msg)
            .then(function(timestamp) {
                toConsole('ACK msg ' + timestamp);
                window.cordova.plugins.watchLink.appLog('ACK msg ' + timestamp);
            })
            .catch(function(err) {
                toConsole('ERR msg:<br>&nbsp;&nbsp;' + err);
                window.cordova.plugins.watchLink.errorLog('ERR msg: ' + err);
            });
    }
    else {
        window.cordova.plugins.watchLink.sendMessage('TEST', msg, null,
            function(err) {
                toConsole('ERR msg:<br>&nbsp;&nbsp;' + err);
                window.cordova.plugins.watchLink.errorLog('ERR msg: ' + err);
            });
    }
    toConsole('msg<br>&nbsp;&nbsp;' + JSON.stringify(msg));
    window.cordova.plugins.watchLink.appLog('msg ' + JSON.stringify(msg));
}

function datamsg(msg) {
    if (msg == null) {
        window.cordova.plugins.watchLink.errorLog('please provide a msg');
        return;
    }
    if (!Array.isArray(msg)) {
        window.cordova.plugins.watchLink.errorLog('msg parameter must be array');
        return;
    }
    var i;
    var buffer = new ArrayBuffer(msg.length);
    var view = new Uint8Array(buffer);
    for (i = 0; i < msg.length; i++) {
        if (typeof msg[i] !== 'number') {
            window.cordova.plugins.watchLink.errorLog('msg[' + i + '] is not a number:', msg[i]);
            return;
        }
        if (msg[i] < 0 || msg[i] > 255) {
            window.cordova.plugins.watchLink.errorLog('msg[' + i + '] is out of range', msg[i]);
            return;
        }
        view[i] = msg[i];
    }
    if (useAck()) {
        window.cordova.plugins.watchLink.sendDataMessage(buffer)
            .then(function() {
                toConsole('ACK datamsg');
                window.cordova.plugins.watchLink.appLog('ACK datamsg');
            })
            .catch(function(err) {
                toConsole('ERR datamsg:<br>&nbsp;&nbsp;' + err);
                window.cordova.plugins.watchLink.errorLog('ERR datamsg: ' + err);
            });
    }
    else {
        window.cordova.plugins.watchLink.sendDataMessage(buffer, null,
            function(err) {
                toConsole('ERR datamsg:<br>&nbsp;&nbsp;' + err);
                window.cordova.plugins.watchLink.errorLog('ERR datamsg: ' + err);
            });
    }
    toConsole('datamsg<br>&nbsp;&nbsp;' + JSON.stringify(msg));
    window.cordova.plugins.watchLink.appLog('datamsg ' + JSON.stringify(msg));
    
}

function testcontext(context) {
    if (context == null) {
        window.cordova.plugins.watchLink.errorLog('please provide a context');
        return;
    }
    if (typeof context !== 'object') {
        window.cordova.plugins.watchLink.errorLog('please provide a context object', context);
        return;
    }
    if (useAck()) {
        window.cordova.plugins.watchLink.sendContext(context)
            .then(function(timestamp) {
                toConsole('ACK context ' + timestamp);
                window.cordova.plugins.watchLink.appLog('ACK context ' + timestamp);
            })
            .catch(function(err) {
                toConsole('ERR context:<br>&nbsp;&nbsp;' + err);
                window.cordova.plugins.watchLink.errorLog('ERR context: ' + err);
            });
    }
    else {
        window.cordova.plugins.watchLink.sendContext(context, null, 
            function(err) {
                toConsole('ERR context:<br>&nbsp;&nbsp;' + err);
                window.cordova.plugins.watchLink.errorLog('ERR context: ' + err);
            });
    }
    toConsole('context<br>&nbsp;&nbsp;' + JSON.stringify(context));
    window.cordova.plugins.watchLink.appLog('context timestamp=' + JSON.stringify(context));
}

function testuserinfo(userinfo) {
    if (userinfo == null) {
        window.cordova.plugins.watchLink.errorLog('please provide userinfo');
        return;
    }
    if (typeof userinfo !== 'object') {
        window.cordova.plugins.watchLink.errorLog('please provide a userinfo object', userinfo);
        return;
    }
    if (useAck()) {
        window.cordova.plugins.watchLink.sendUserInfo(userinfo)
            .then(function(timestamp) {
                toConsole('ACK userinfo ' + timestamp);
                window.cordova.plugins.watchLink.appLog('ACK userinfo ' + timestamp);
            })
            .catch(function(err) {
                toConsole('ERR userinfo:<br>&nbsp;&nbsp;' + err);
                window.cordova.plugins.watchLink.errorLog('ERR userinfo: ' + err);
            });
        toConsole('testuserinfo timestamp=' + userinfo.TIMESTAMP);
        window.cordova.plugins.watchLink.appLog('testuserinfo timestamp=' + userinfo.TIMESTAMP);
    }
    else {
        window.cordova.plugins.watchLink.sendUserInfo(userinfo, null,
            function(err) {
                toConsole('ERR userinfo:<br>&nbsp;&nbsp;' + err);
                window.cordova.plugins.watchLink.errorLog('ERR userinfo: ' + err);
            });
    }
    toConsole('userinfo<br>&nbsp;&nbsp;' + JSON.stringify(userinfo));
    window.cordova.plugins.watchLink.appLog('userinfo ' + JSON.stringify(userinfo));
}

function notify(delay, title, subtitle, body, userInfo) {
    delay = (delay == null ? 10 : delay);
    title = title || 'Test alert';
    subtitle = subtitle || '';
    body = body || '';
    userInfo = userInfo || {};
    window.cordova.plugins.watchLink.scheduleNotification(delay, { title: title, subtitle: subtitle, body: body, userInfo: userInfo })
        .then(
          function(timestamp) {
            lastNotification = timestamp;
            toConsole('Notification sent: ' + timestamp);
            window.cordova.plugins.watchLink.appLog('Notification sent: ' + timestamp);
            pendingNotifications();
        })
        .catch(
           function(msg) {
                window.cordova.plugins.watchLink.appLog('Notifications denied: ' + msg);
        });
}

function cancelNotification(timestamp) {
    timestamp = timestamp || lastNotification;
    if (timestamp) {
        window.cordova.plugins.watchLink.cancelNotification(timestamp);
        toConsole('Notification cancelled');
        window.cordova.plugins.watchLink.appLog('Notification cancelled');
        lastNotification = null;
    }
    else {
        toConsole('No pending notification');
        window.cordova.plugins.watchLink.appLog('No pending notification');
    }
}

function cancelAllNotifications() {
    window.cordova.plugins.watchLink.cancelAllNotifications();
    toConsole('All notifications cancelled');
    window.cordova.plugins.watchLink.appLog('All notifications cancelled');
    lastNotification = null;
}

function pendingNotifications() {
    window.cordova.plugins.watchLink.retrieveNotifications()
      .then(
        function(list) {
            toConsole('Notifications pending: ' + list.length);
            list.forEach(
                function(el) {
                    addConsole('<br>&nbsp;&nbsp;' + JSON.stringify(el));
                });
            window.cordova.plugins.watchLink.appLog('Notifications pending: ' + JSON.stringify(list));
        });
}

document.getElementById('testmsg').addEventListener('click',
function() {
    var obj = { a: Math.floor(Math.random() * 255), b: Math.floor(Math.random() * 255) };
    testmsg(obj);
});

document.getElementById('testdatamsg').addEventListener('click',
function() {
    var obj = [ Math.floor(Math.random() * 255),Math.floor(Math.random() * 255) ];
    datamsg(obj);
});

document.getElementById('userinfo').addEventListener('click',
function() {
    var obj = { x: Math.floor(Math.random() * 255), y: Math.floor(Math.random() * 255) };
    testuserinfo(obj);
});

document.getElementById('context').addEventListener('click',
function() {
    var obj = { z: Math.floor(Math.random() * 255), w: Math.floor(Math.random() * 255) };
    testcontext(obj);
});

document.getElementById('notification').addEventListener('click',
function() {
    var n = Math.floor(Math.random() * 255);
    notify(10, 'Notify ' + n, 'Subtitle ' + n, 'Body of notification ' + n, { id: n });
});

document.getElementById('cancelnotification').addEventListener('click',
function() {
    cancelNotification();
});

document.getElementById('cancelallnotifications').addEventListener('click',
function() {
    cancelAllNotifications();
});

document.getElementById('listnotifications').addEventListener('click',
function() {
    pendingNotifications();
});

document.getElementById('resetsession').addEventListener('click',
function() {
    reset();
});

document.getElementById('clearconsole').addEventListener('click', clearConsole);
